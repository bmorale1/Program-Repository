
/**
 * Competitor's code. 
 * Must implement the required method in the interface
 * 
 * @author Darth 
 * @version 3/28/2016
 */
public class FunEncryptor implements CanEncrypt
{
    //Provide a concrete implmentation of th emethod
    public String cesarCrypt(String plaintext){
        //Code goes here
        return "";
    }
}
