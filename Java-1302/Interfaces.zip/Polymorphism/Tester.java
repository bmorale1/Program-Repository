
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tester
{
   public static void main(String[] args){
       Encryptor e1 = new Encryptor();
       System.out.println(e1.cesarCrypt("Hello World"));
       
    }
}
