
/**
 * Specifies teh required behaviors/algorithims
 * 
 * @author TSYS 
 * @version 3/28/2016
 */
public interface CanEncrypt
{
    //Abstract method definition
    /**
     * This method is supposed to implement the shift by 3 caesar cipher
     */
    String cesarCrypt(String plaintext);
    //Can have other abstract method definitions
}
